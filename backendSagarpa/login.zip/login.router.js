const router = require('express').Router();

module.exports = (wagner) => {
    const loginCtrl = wagner.invoke((User) => 
        require('../controllers/login.controller')(User));

    router.post('/', (req, res) =>
        loginCtrl.login(req, res));
    
    return router;
};