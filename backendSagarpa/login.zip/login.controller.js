const status = require('http-status');
const handler = require('../utils/handler');
const jwt = require('jsonwebtoken');
const config = require('../_config');

// collection I need
let _user;

const login = (req, res) => {
    let user = req.body;
    _user.findOne({ 'username': user.username, 'password': user.password })
        .then(user => {
            if (user) {
                user.password = undefined;
                return res.json({
                    userInfo: user,
                    token: jwt.sign({
                        username: user.username,
                        password: user.password,
                        _id: user._id
                    },
                        config.secret)
                });
            } else {
                return res.status(status.BAD_REQUEST).json({
                    code: status.BAD_REQUEST,
                    message: 'Credenciales no válidas',
                    detail: 'Usuario y/o contraseña incorrectos'
                });
            }
        });
};

module.exports = (User) => {
    _user = User;
    return ({
        login
    });
}